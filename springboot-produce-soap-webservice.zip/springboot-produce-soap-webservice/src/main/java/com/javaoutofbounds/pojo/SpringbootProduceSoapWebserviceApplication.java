package com.javaoutofbounds.pojo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootProduceSoapWebserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootProduceSoapWebserviceApplication.class, args);
	}
}
