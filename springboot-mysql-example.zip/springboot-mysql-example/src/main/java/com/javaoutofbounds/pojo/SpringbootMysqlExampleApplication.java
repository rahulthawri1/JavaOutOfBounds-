package com.javaoutofbounds.pojo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootMysqlExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootMysqlExampleApplication.class, args);
	}
}
